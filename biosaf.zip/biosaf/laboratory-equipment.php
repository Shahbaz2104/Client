<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/bootstrap.php';

$pageTitle = 'Laboratory Equipment Sales & Procurement';
$metaDescription = 'Procurement of analytical instruments, lab glassware, testing kits, and scientific equipment from BIOSAF Enterprises.';
$activePage = 'divisions';
$navStyle = 'sticky';
$bodyClass = 'font-sans text-slate-700 antialiased bg-brand-light selection:bg-brand-accent selection:text-brand-dark';
$preloaderIcon = 'ph-bold ph-dna';
$preloaderSubtext = 'Scientific Sourcing & Procurement';
$pageScripts = ['laboratory-equipment.js'];

require BIOSAF_INCLUDES . '/header.php';
?>

<!-- Hero Banner Presentation Section -->
    <section class="relative pt-24 pb-20 md:pt-36 md:pb-32 bg-brand-dark overflow-hidden text-white">
        <!-- Digital background map layers -->
        <div class="absolute inset-0 z-0">
            <div class="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,rgba(26,89,53,0.5),transparent_60%)]"></div>
            <div class="absolute bottom-[-10%] left-[-10%] w-[50%] h-[50%] bg-[radial-gradient(circle,rgba(211,243,64,0.05),transparent_70%)]"></div>
            <div class="absolute inset-0 opacity-[0.03] bg-[linear-gradient(to_right,#FFF_1px,transparent_1px),linear-gradient(to_bottom,#FFF_1px,transparent_1px)] bg-[size:32px_32px]"></div>
        </div>

        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
            <div class="grid lg:grid-cols-12 gap-12 items-center">
                <!-- Text Area -->
                <div class="lg:col-span-7 space-y-8">
                    <div class="inline-flex items-center gap-2 bg-white/5 border border-white/10 text-brand-accent px-4 py-2 rounded-full text-xs font-semibold tracking-wider uppercase backdrop-blur-sm">
                        <span class="w-2.5 h-2.5 rounded-full bg-brand-accent animate-pulse"></span>
                        Trusted Global Supplier Network
                    </div>
                    
                    <h1 class="text-4xl sm:text-6xl lg:text-7xl font-extrabold leading-[1.1] tracking-tight">
                        Empowering discovery through <span class="text-brand-accent italic font-serif">precision</span> sourcing
                    </h1>
                    
                    <p class="text-lg text-gray-300 max-w-xl leading-relaxed">
                        BIOSAF Enterprises provides global clinical and chemical infrastructure procurement, lab furniture configurations, and high-performance equipment to verify full regulatory compliance and scientific integrity.
                    </p>

                    <!-- Interactive Sourcing Search Widget -->
                    <div class="max-w-lg bg-white/5 p-2 rounded-2xl shadow-2xl flex items-center border border-white/10 backdrop-blur-md">
                        <i class="ph-bold ph-magnifying-glass text-brand-accent text-xl ml-3"></i>
                        <input type="text" id="procurement-search" placeholder="Search instruments, CAS chemicals, glassware..." class="w-full bg-transparent border-none py-3 px-3 text-white placeholder-gray-400 focus:outline-none focus:ring-0 text-sm">
                        <button onclick="simulateSearch()" class="bg-brand-accent hover:bg-brand-accentHover text-brand-dark font-black text-xs px-6 py-3.5 rounded-xl uppercase tracking-wide transition-colors">
                            Find Item
                        </button>
                    </div>

                    <!-- Trust Signals -->
                    <div class="pt-6 border-t border-white/10 grid grid-cols-3 gap-4 max-w-md text-xs">
                        <div class="flex items-center gap-2">
                            <i class="ph-bold ph-seal-check text-brand-accent text-lg"></i>
                            <span class="text-slate-300 font-medium">OEM Warranties Included</span>
                        </div>
                        <div class="flex items-center gap-2">
                            <i class="ph-bold ph-truck text-brand-accent text-lg"></i>
                            <span class="text-slate-300 font-medium">Compliance Logistics</span>
                        </div>
                        <div class="flex items-center gap-2">
                            <i class="ph-bold ph-wrench text-brand-accent text-lg"></i>
                            <span class="text-slate-300 font-medium">Full Calibration</span>
                        </div>
                    </div>
                </div>

                <!-- Graphic/Visual Frame -->
                <div class="lg:col-span-5 relative">
                    <div class="relative mx-auto max-w-[420px] lg:max-w-none">
                        <!-- Neon ambient glow -->
                        <div class="absolute -top-6 -left-6 w-48 h-48 bg-brand-accent rounded-full opacity-10 blur-3xl"></div>
                        <div class="absolute -bottom-6 -right-6 w-56 h-56 bg-brand-secondary rounded-full opacity-20 blur-3xl"></div>

                        <!-- Main Graphic Frame -->
                        <div class="relative z-10 rounded-[2.5rem] overflow-hidden border border-white/10 shadow-2xl animate-float">
                            <img src="https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" alt="Advanced Analytical Laboratory Sourcing" class="w-full object-cover aspect-[4/3] sm:aspect-square" />
                            <div class="absolute inset-0 bg-gradient-to-t from-brand-dark via-transparent to-transparent"></div>
                        </div>

                        <section id="overview" class="py-24 bg-white border-b border-gray-100">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="grid lg:grid-cols-12 gap-12 lg:gap-20 items-center">
                
                <!-- Left Visual Aspect -->
                <div class="lg:col-span-5 relative reveal">
                    <div class="relative grid grid-cols-12 gap-3">
                        <div class="col-span-11 rounded-[2.5rem] overflow-hidden shadow-2xl">
                            <img src="https://images.unsplash.com/photo-1579154204601-01588f351167?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" alt="Laboratory testing workflow" class="w-full object-cover aspect-[4/5]" />
                        </div>
                        <div class="absolute bottom-[-20px] right-0 w-[180px] rounded-2xl overflow-hidden shadow-2xl border-4 border-white">
                            <img src="https://images.unsplash.com/photo-1582719508461-905c673771fd?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80" alt="Liquid chromatography analyzer" class="w-full aspect-square object-cover" />
                        </div>
                    </div>
                </div>

                <!-- Narrative Overview -->
                <div class="lg:col-span-7 space-y-6 reveal">
                    <span class="text-brand-primary text-xs font-bold tracking-widest uppercase bg-brand-light px-3.5 py-1.5 rounded-full inline-block">
                        Enterprise Sourcing Framework
                    </span>
                    <h2 class="text-3xl sm:text-5xl font-black text-brand-dark tracking-tight">
                        Simplifying critical scientific procurement with high efficiency
                    </h2>
                    <div class="space-y-4 text-slate-600 leading-relaxed text-base">
                        <p class="font-bold text-brand-primary">
                            BIOSAF Enterprises acts as the premier procurement integrator for high-complexity laboratory installations, cold-chain chemicals, and diagnostic instruments.
                        </p>
                        <p>
                            We address the complexities of sourcing delicate glassware, hazardous chemicals, and micro-precision analytical tools by managing the complete supply chain—from initial manufacturer evaluation to direct white-glove site delivery, calibration, and support.
                        </p>
                        <p>
                            Every source partner and shipment is checked under our rigorous internal ISO criteria to secure pristine compliance with international scientific standards.
                        </p>
                    </div>
                    <div class="grid sm:grid-cols-2 gap-4 pt-4 border-t border-gray-100">
                        <div class="flex items-center gap-3">
                            <i class="ph-bold ph-shield-check text-brand-secondary text-xl"></i>
                            <span class="font-bold text-brand-dark text-sm">Full Technical Compliance Auditing</span>
                        </div>
                        <div class="flex items-center gap-3">
                            <i class="ph-bold ph-globe-hemisphere-east text-brand-secondary text-xl"></i>
                            <span class="font-bold text-brand-dark text-sm">Cross-Border Logistics Network</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Product Categories Section -->
    <section id="categories" class="py-24 bg-[#F8FAF6] relative border-b border-gray-100">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center max-w-2xl mx-auto mb-16 reveal">
                <span class="text-brand-primary text-xs font-bold tracking-widest uppercase bg-white border border-gray-100 px-4 py-2 rounded-full inline-block">
                    Procurement Sectors
                </span>
                <h2 class="text-3xl sm:text-5xl font-extrabold text-brand-dark mt-4">
                    Complete Laboratory Portfolio
                </h2>
                <p class="text-slate-600 mt-2">Explore targeted divisions optimized for corporate, research, and diagnostic applications.</p>
            </div>

            <!-- Tabbed Selector Bar -->
            <div class="flex flex-wrap justify-center gap-2 mb-12 reveal">
                <button onclick="switchCategory('all')" id="tab-all" class="category-tab px-5 py-3 rounded-xl font-bold text-xs uppercase tracking-wide transition-all bg-brand-primary text-white shadow-md">
                    All Categories
                </button>
                <button onclick="switchCategory('instruments')" id="tab-instruments" class="category-tab px-5 py-3 rounded-xl font-bold text-xs uppercase tracking-wide transition-all bg-white text-slate-600 hover:bg-slate-100">
                    Analytical Instruments
                </button>
                <button onclick="switchCategory('testing')" id="tab-testing" class="category-tab px-5 py-3 rounded-xl font-bold text-xs uppercase tracking-wide transition-all bg-white text-slate-600 hover:bg-slate-100">
                    Testing Systems
                </button>
                <button onclick="switchCategory('consumables')" id="tab-consumables" class="category-tab px-5 py-3 rounded-xl font-bold text-xs uppercase tracking-wide transition-all bg-white text-slate-600 hover:bg-slate-100">
                    Consumables &amp; Infrastructure
                </button>
            </div>

            <!-- Grid System for Categories -->
            <div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-8" id="category-grid">
                
                <!-- Category 1: Analytical Instruments -->
                <div class="bg-white rounded-3xl p-8 border border-gray-100 spec-card transition-all duration-300 hover:-translate-y-1 relative overflow-hidden group" data-category="instruments">
                    <div class="w-12 h-12 bg-brand-light text-brand-primary rounded-2xl flex items-center justify-center mb-6 group-hover:bg-brand-primary group-hover:text-brand-accent transition-colors">
                        <i class="ph-bold ph-graph text-2xl"></i>
                    </div>
                    <h3 class="font-extrabold text-slate-950 text-lg mb-2">Analytical Instruments</h3>
                    <p class="text-xs text-slate-500 leading-relaxed mb-4">Precision spectrometers, high-pressure liquid chromatographs, and automated titrators.</p>
                    <ul class="space-y-2 mb-6 text-xs text-slate-600 font-bold">
                        <li class="flex items-center gap-1.5"><i class="ph ph-check text-brand-secondary"></i> HPLC &amp; Gas Systems</li>
                        <li class="flex items-center gap-1.5"><i class="ph ph-check text-brand-secondary"></i> High-resolution Spectrophotometry</li>
                    </ul>
                    <a href="#featured" class="text-xs font-bold text-brand-secondary flex items-center gap-1 group-hover:underline">
                        Explore Systems <i class="ph ph-caret-right"></i>
                    </a>
                </div>

                <!-- Category 2: Glassware -->
                <div class="bg-white rounded-3xl p-8 border border-gray-100 spec-card transition-all duration-300 hover:-translate-y-1 relative overflow-hidden group" data-category="consumables">
                    <div class="w-12 h-12 bg-brand-light text-brand-primary rounded-2xl flex items-center justify-center mb-6 group-hover:bg-brand-primary group-hover:text-brand-accent transition-colors">
                        <i class="ph-bold ph-flask text-2xl"></i>
                    </div>
                    <h3 class="font-extrabold text-slate-950 text-lg mb-2">Glassware &amp; Consumables</h3>
                    <p class="text-xs text-slate-500 leading-relaxed mb-4">Borosilicate glassware, calibrated beakers, graduated pipettes, and standard sterile containers.</p>
                    <ul class="space-y-2 mb-6 text-xs text-slate-600 font-bold">
                        <li class="flex items-center gap-1.5"><i class="ph ph-check text-brand-secondary"></i> Calibrated Glass Cylinders</li>
                        <li class="flex items-center gap-1.5"><i class="ph ph-check text-brand-secondary"></i> Premium Duran Standard Vessels</li>
                    </ul>
                    <a href="#featured" class="text-xs font-bold text-brand-secondary flex items-center gap-1 group-hover:underline">
                        Explore Glassware <i class="ph ph-caret-right"></i>
                    </a>
                </div>

                <!-- Category 3: Chemicals -->
                <div class="bg-white rounded-3xl p-8 border border-gray-100 spec-card transition-all duration-300 hover:-translate-y-1 relative overflow-hidden group" data-category="consumables">
                    <div class="w-12 h-12 bg-brand-light text-brand-primary rounded-2xl flex items-center justify-center mb-6 group-hover:bg-brand-primary group-hover:text-brand-accent transition-colors">
                        <i class="ph-bold ph-test-tube text-2xl"></i>
                    </div>
                    <h3 class="font-extrabold text-slate-950 text-lg mb-2">High-Purity Chemicals</h3>
                    <p class="text-xs text-slate-500 leading-relaxed mb-4">Analytical-grade solvents, standard buffers, synthesis reagents, and certified organic chemistry.</p>
                    <ul class="space-y-2 mb-6 text-xs text-slate-600 font-bold">
                        <li class="flex items-center gap-1.5"><i class="ph ph-check text-brand-secondary"></i> CAS certified analytical grade</li>
                        <li class="flex items-center gap-1.5"><i class="ph ph-check text-brand-secondary"></i> Safe controlled chemical storage options</li>
                    </ul>
                    <a href="#featured" class="text-xs font-bold text-brand-secondary flex items-center gap-1 group-hover:underline">
                        Explore Reagents <i class="ph ph-caret-right"></i>
                    </a>
                </div>

                <!-- Category 4: Laboratory Furniture -->
                <div class="bg-white rounded-3xl p-8 border border-gray-100 spec-card transition-all duration-300 hover:-translate-y-1 relative overflow-hidden group" data-category="consumables">
                    <div class="w-12 h-12 bg-brand-light text-brand-primary rounded-2xl flex items-center justify-center mb-6 group-hover:bg-brand-primary group-hover:text-brand-accent transition-colors">
                        <i class="ph-bold ph-cabinet text-2xl"></i>
                    </div>
                    <h3 class="font-extrabold text-slate-950 text-lg mb-2">Furniture &amp; Safety Hubs</h3>
                    <p class="text-xs text-slate-500 leading-relaxed mb-4">Acid-resistant workstations, laminar flow cabinets, safety fume hoods, and ergonomic laboratory layouts.</p>
                    <ul class="space-y-2 mb-6 text-xs text-slate-600 font-bold">
                        <li class="flex items-center gap-1.5"><i class="ph ph-check text-brand-secondary"></i> Integrated air-handling exhaust</li>
                        <li class="flex items-center gap-1.5"><i class="ph ph-check text-brand-secondary"></i> Chemically treated worktops</li>
                    </ul>
                    <a href="#featured" class="text-xs font-bold text-brand-secondary flex items-center gap-1 group-hover:underline">
                        Explore Infrastructure <i class="ph ph-caret-right"></i>
                    </a>
                </div>

                <!-- Category 5: Water Testing -->
                <div class="bg-white rounded-3xl p-8 border border-gray-100 spec-card transition-all duration-300 hover:-translate-y-1 relative overflow-hidden group" data-category="testing">
                    <div class="w-12 h-12 bg-brand-light text-brand-primary rounded-2xl flex items-center justify-center mb-6 group-hover:bg-brand-primary group-hover:text-brand-accent transition-colors">
                        <i class="ph-bold ph-drop text-2xl"></i>
                    </div>
                    <h3 class="font-extrabold text-slate-950 text-lg mb-2">Water Quality Testing</h3>
                    <p class="text-xs text-slate-500 leading-relaxed mb-4">Multi-parameter photometers, digital pH instruments, conductivity analyzers, and standard microbiological test kits.</p>
                    <ul class="space-y-2 mb-6 text-xs text-slate-600 font-bold">
                        <li class="flex items-center gap-1.5"><i class="ph ph-check text-brand-secondary"></i> Dissolved oxygen trace analysis</li>
                        <li class="flex items-center gap-1.5"><i class="ph ph-check text-brand-secondary"></i> High-accuracy digital sensors</li>
                    </ul>
                    <a href="#featured" class="text-xs font-bold text-brand-secondary flex items-center gap-1 group-hover:underline">
                        Explore Analysis <i class="ph ph-caret-right"></i>
                    </a>
                </div>

                <!-- Category 6: Food Testing -->
                <div class="bg-white rounded-3xl p-8 border border-gray-100 spec-card transition-all duration-300 hover:-translate-y-1 relative overflow-hidden group" data-category="testing">
                    <div class="w-12 h-12 bg-brand-light text-brand-primary rounded-2xl flex items-center justify-center mb-6 group-hover:bg-brand-primary group-hover:text-brand-accent transition-colors">
                        <i class="ph-bold ph-cookie text-2xl"></i>
                    </div>
                    <h3 class="font-extrabold text-slate-950 text-lg mb-2">Food Quality Testing</h3>
                    <p class="text-xs text-slate-500 leading-relaxed mb-4">Rapid pathogen test devices, food matrix fat analyzers, gluten sensors, and moisture analytical balances.</p>
                    <ul class="space-y-2 mb-6 text-xs text-slate-600 font-bold">
                        <li class="flex items-center gap-1.5"><i class="ph ph-check text-brand-secondary"></i> Rapid allergen detection kits</li>
                        <li class="flex items-center gap-1.5"><i class="ph ph-check text-brand-secondary"></i> High-precision moisture balances</li>
                    </ul>
                    <a href="#featured" class="text-xs font-bold text-brand-secondary flex items-center gap-1 group-hover:underline">
                        Explore Systems <i class="ph ph-caret-right"></i>
                    </a>
                </div>

                <!-- Category 7: Scientific Equipment -->
                <div class="bg-white rounded-3xl p-8 border border-gray-100 spec-card transition-all duration-300 hover:-translate-y-1 relative overflow-hidden group col-span-1 sm:col-span-2 lg:col-span-3" data-category="instruments">
                    <div class="w-12 h-12 bg-brand-light text-brand-primary rounded-2xl flex items-center justify-center mb-6 group-hover:bg-brand-primary group-hover:text-brand-accent transition-colors">
                        <i class="ph-bold ph-spiral text-2xl"></i>
                    </div>
                    <h3 class="font-extrabold text-slate-950 text-lg mb-2">High-Capacity Centrifuges &amp; Incubators</h3>
                    <p class="text-xs text-slate-500 leading-relaxed mb-4">Refrigerated ultra-centrifuges, orbital incubation shakers, high-temperature muffle ovens, and deep freezer cooling installations.</p>
                    <ul class="space-y-2 mb-6 text-xs text-slate-600 font-bold grid sm:grid-cols-2 gap-2">
                        <li class="flex items-center gap-1.5"><i class="ph ph-check text-brand-secondary"></i> Micro-processor control screens</li>
                        <li class="flex items-center gap-1.5"><i class="ph ph-check text-brand-secondary"></i> Cold-chain verification outputs</li>
                    </ul>
                    <a href="#featured" class="text-xs font-bold text-brand-secondary flex items-center gap-1 group-hover:underline">
                        Explore Heavy Hardware <i class="ph ph-caret-right"></i>
                    </a>
                </div>

            </div>
        </div>
    </section>

    <!-- Featured Products Section with Live Sourcing Actions -->
    <section id="featured" class="py-24 bg-white relative border-b border-gray-100">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center max-w-2xl mx-auto mb-16 reveal">
                <span class="text-brand-primary text-xs font-bold tracking-widest uppercase bg-brand-light px-4 py-2 rounded-full inline-block">
                    Procurement Spotlight
                </span>
                <h2 class="text-3xl sm:text-5xl font-extrabold text-brand-dark mt-4">
                    Featured Systems &amp; Instruments
                </h2>
                <p class="text-slate-600 mt-2">Add items directly to your consolidated quote manifest for rapid corporate bidding.</p>
            </div>

            <!-- Products Catalog -->
            <div class="grid md:grid-cols-3 gap-8">
                <!-- Product Card 1 -->
                <div class="border border-gray-100 rounded-3xl overflow-hidden hover:shadow-2xl hover:border-brand-accent/30 transition-all flex flex-col justify-between group bg-brand-light">
                    <div class="relative bg-slate-100 aspect-[4/3] overflow-hidden">
                        <img src="https://images.unsplash.com/photo-1518152006812-edab29b069ac?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" alt="Spectrophotometer Analysis" class="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" />
                        <span class="absolute top-4 left-4 bg-brand-primary text-white text-[10px] font-bold tracking-wider uppercase px-2.5 py-1 rounded-md border border-brand-accent/20">Precision Class</span>
                    </div>
                    <div class="p-8 space-y-4 flex-grow flex flex-col justify-between">
                        <div class="space-y-2">
                            <h3 class="text-lg font-bold text-brand-dark">Spectrophotometer UV-Vis Elite</h3>
                            <p class="text-xs text-slate-500">Double-beam spectral monitoring system utilizing precision xenon flash lamps. Perfect for pharmaceutical analysis workflows.</p>
                            <div class="pt-2 flex flex-wrap gap-1">
                                <span class="inline-block bg-white text-slate-700 text-[10px] font-bold px-2 py-1 rounded border border-gray-200">Accuracy: ±0.002 A</span>
                                <span class="inline-block bg-white text-slate-700 text-[10px] font-bold px-2 py-1 rounded border border-gray-200">Range: 190–1100 nm</span>
                            </div>
                        </div>
                        <button onclick="addToQuote('Spectrophotometer UV-Vis Elite')" class="w-full bg-brand-primary hover:bg-brand-accent hover:text-brand-dark text-white text-xs font-black py-4 rounded-xl uppercase tracking-wider transition-colors flex items-center justify-center gap-2">
                            <i class="ph-bold ph-plus"></i> Add to Sourcing List
                        </button>
                    </div>
                </div>

                <!-- Product Card 2 -->
                <div class="border border-gray-100 rounded-3xl overflow-hidden hover:shadow-2xl hover:border-brand-accent/30 transition-all flex flex-col justify-between group bg-brand-light">
                    <div class="relative bg-slate-100 aspect-[4/3] overflow-hidden">
                        <img src="https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" alt="HPLC Sourcing" class="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" />
                        <span class="absolute top-4 left-4 bg-brand-primary text-white text-[10px] font-bold tracking-wider uppercase px-2.5 py-1 rounded-md border border-brand-accent/20">Analytical Standard</span>
                    </div>
                    <div class="p-8 space-y-4 flex-grow flex flex-col justify-between">
                        <div class="space-y-2">
                            <h3 class="text-lg font-bold text-brand-dark">HPLC Chromasolv Processor</h3>
                            <p class="text-xs text-slate-500">High-performance liquid chromatography station with automatic sampling systems and full trace integration software.</p>
                            <div class="pt-2 flex flex-wrap gap-1">
                                <span class="inline-block bg-white text-slate-700 text-[10px] font-bold px-2 py-1 rounded border border-gray-200">Pressure: Max 600 Bar</span>
                                <span class="inline-block bg-white text-slate-700 text-[10px] font-bold px-2 py-1 rounded border border-gray-200">Temp: 4–60°C</span>
                            </div>
                        </div>
                        <button onclick="addToQuote('HPLC Chromasolv Processor')" class="w-full bg-brand-primary hover:bg-brand-accent hover:text-brand-dark text-white text-xs font-black py-4 rounded-xl uppercase tracking-wider transition-colors flex items-center justify-center gap-2">
                            <i class="ph-bold ph-plus"></i> Add to Sourcing List
                        </button>
                    </div>
                </div>

                <!-- Product Card 3 -->
                <div class="border border-gray-100 rounded-3xl overflow-hidden hover:shadow-2xl hover:border-brand-accent/30 transition-all flex flex-col justify-between group bg-brand-light">
                    <div class="relative bg-slate-100 aspect-[4/3] overflow-hidden">
                        <img src="https://images.unsplash.com/photo-1576086213369-97a306d36557?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" alt="High speed benchtop centrifuge" class="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" />
                        <span class="absolute top-4 left-4 bg-brand-primary text-white text-[10px] font-bold tracking-wider uppercase px-2.5 py-1 rounded-md border border-brand-accent/20">Safety Approved</span>
                    </div>
                    <div class="p-8 space-y-4 flex-grow flex flex-col justify-between">
                        <div class="space-y-2">
                            <h3 class="text-lg font-bold text-brand-dark">Refrigerated Centrifuge R-150</h3>
                            <p class="text-xs text-slate-500">Brushless induction motor benchtop centrifuge with electronic safety locking systems and cooling control modules.</p>
                            <div class="pt-2 flex flex-wrap gap-1">
                                <span class="inline-block bg-white text-slate-700 text-[10px] font-bold px-2 py-1 rounded border border-gray-200">Speed: 15,000 RPM</span>
                                <span class="inline-block bg-white text-slate-700 text-[10px] font-bold px-2 py-1 rounded border border-gray-200">Volume: 4 x 250ml</span>
                            </div>
                        </div>
                        <button onclick="addToQuote('Refrigerated Centrifuge R-150')" class="w-full bg-brand-primary hover:bg-brand-accent hover:text-brand-dark text-white text-xs font-black py-4 rounded-xl uppercase tracking-wider transition-colors flex items-center justify-center gap-2">
                            <i class="ph-bold ph-plus"></i> Add to Sourcing List
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Brand Sourcing Alliances -->
    <section id="brands" class="py-20 bg-[#F8FAF6] border-b border-gray-100 overflow-hidden">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h3 class="text-xs font-bold text-slate-400 uppercase tracking-widest mb-10">Authorized Distributor of Premier Scientific Brands</h3>
            
            <div class="flex flex-wrap justify-center items-center gap-12 opacity-60">
                <div class="flex items-center gap-2 font-black text-brand-dark text-sm tracking-widest"><i class="ph ph-cube text-2xl text-brand-secondary"></i> MERCK SOURCE</div>
                <div class="flex items-center gap-2 font-black text-brand-dark text-sm tracking-widest"><i class="ph ph-atom text-2xl text-brand-secondary"></i> DURAN GLASS</div>
                <div class="flex items-center gap-2 font-black text-brand-dark text-sm tracking-widest"><i class="ph ph-shield-check text-2xl text-brand-secondary"></i> SIGMA REAGENTS</div>
                <div class="flex items-center gap-2 font-black text-brand-dark text-sm tracking-widest"><i class="ph ph-sparkles text-2xl text-brand-secondary"></i> THERMO ALIGNED</div>
            </div>
        </div>
    </section>

    <!-- Procurement Process Section -->
    <section id="process" class="py-24 bg-brand-dark text-white relative overflow-hidden">
        <div class="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom_left,rgba(26,89,53,0.3),transparent_60%)]"></div>
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
            <div class="text-center max-w-2xl mx-auto mb-20 reveal">
                <span class="text-brand-accent text-xs font-bold tracking-widest uppercase bg-white/5 border border-white/10 px-4 py-2 rounded-full inline-block">
                    Procurement Lifecycle
                </span>
                <h2 class="text-3xl sm:text-5xl font-extrabold mt-6 mb-4">How BIOSAF Sourcing Works</h2>
                <p class="text-slate-300">From validation of technical configurations to compliant white-glove shipping setups.</p>
            </div>

            <!-- Sourcing flow milestones -->
            <div class="grid md:grid-cols-4 gap-8">
                <!-- Step 1 -->
                <div class="bg-white/5 border border-white/10 rounded-3xl p-8 relative group reveal">
                    <div class="absolute -top-5 left-8 w-10 h-10 bg-brand-accent text-brand-dark rounded-xl flex items-center justify-center font-black text-sm shadow-md">
                        1
                    </div>
                    <h3 class="text-xl font-bold mt-2 mb-3">Specification Review</h3>
                    <p class="text-slate-300 text-xs leading-relaxed">Submit your research equipment manifest or instrument specification sheets directly to our analytical and chemical engineers.</p>
                </div>

                <!-- Step 2 -->
                <div class="bg-white/5 border border-white/10 rounded-3xl p-8 relative group reveal">
                    <div class="absolute -top-5 left-8 w-10 h-10 bg-brand-accent text-brand-dark rounded-xl flex items-center justify-center font-black text-sm shadow-md">
                        2
                    </div>
                    <h3 class="text-xl font-bold mt-2 mb-3">Global Bidding</h3>
                    <p class="text-slate-300 text-xs leading-relaxed">We source the equipment through verified OEM suppliers to secure institutional cost pricing advantages for you.</p>
                </div>

                <!-- Step 3 -->
                <div class="bg-white/5 border border-white/10 rounded-3xl p-8 relative group reveal">
                    <div class="absolute -top-5 left-8 w-10 h-10 bg-brand-accent text-brand-dark rounded-xl flex items-center justify-center font-black text-sm shadow-md">
                        3
                    </div>
                    <h3 class="text-xl font-bold mt-2 mb-3">Compliance Logistics</h3>
                    <p class="text-slate-300 text-xs leading-relaxed">All delicate items are packed in compliance with hazardous/fragile standards and handled using tracked express networks.</p>
                </div>

                <!-- Step 4 -->
                <div class="bg-white/5 border border-white/10 rounded-3xl p-8 relative group reveal">
                    <div class="absolute -top-5 left-8 w-10 h-10 bg-brand-accent text-brand-dark rounded-xl flex items-center justify-center font-black text-sm shadow-md">
                        4
                    </div>
                    <h3 class="text-xl font-bold mt-2 mb-3">Site Calibration</h3>
                    <p class="text-slate-300 text-xs leading-relaxed">Our qualified field technicians perform physical integration, functional testing, and calibration with full certificate log transfer.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Industries Served Grid Section -->
    <section class="py-24 bg-white relative">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="grid lg:grid-cols-12 gap-12 items-center">
                
                <!-- Left Hand Features description -->
                <div class="lg:col-span-5 reveal">
                    <span class="text-brand-primary text-xs font-bold tracking-widest uppercase bg-brand-light px-3.5 py-1.5 rounded-full inline-block">
                        Why Choose BIOSAF Sourcing?
                    </span>
                    <h2 class="text-3xl sm:text-5xl font-black text-brand-dark mt-4 mb-4">
                        Quality Integrity Verified At Every Stage
                    </h2>
                    <p class="text-slate-600 leading-relaxed text-base">
                        We coordinate with universities, hospitals, research centers, and food industrial plants to maintain active high-throughput clinical laboratory layouts.
                    </p>
                    <div class="mt-6 border-l-4 border-brand-accent pl-6 py-1">
                        <p class="font-serif italic text-lg text-brand-primary">
                            "Uncompromising precision in scientific supplies ensures consistent scientific data outcomes."
                        </p>
                    </div>
                </div>

                <!-- Right Hand Industries Served grid -->
                <div class="lg:col-span-7 grid sm:grid-cols-2 gap-4 reveal">
                    <div class="p-6 bg-[#F8FAF6] border border-gray-100 rounded-3xl">
                        <h3 class="font-bold text-brand-dark text-sm flex items-center gap-2"><i class="ph ph-heartbeat text-brand-secondary"></i> Medical &amp; Clinical Diagnostics</h3>
                        <p class="text-xs text-slate-500 mt-2">Equipping hospitals with digital blood chemistry analyzers and high-capacity sterile centrifuge centers.</p>
                    </div>
                    <div class="p-6 bg-[#F8FAF6] border border-gray-100 rounded-3xl">
                        <h3 class="font-bold text-brand-dark text-sm flex items-center gap-2"><i class="ph ph-shield-check text-brand-secondary"></i> Pharmaceutical Cleanrooms</h3>
                        <p class="text-xs text-slate-500 mt-2">Precision liquid chromatography and laminar workstations conforming to pristine validation norms.</p>
                    </div>
                    <div class="p-6 bg-[#F8FAF6] border border-gray-100 rounded-3xl">
                        <h3 class="font-bold text-brand-dark text-sm flex items-center gap-2"><i class="ph ph-tree text-brand-secondary"></i> Food &amp; Water Security</h3>
                        <p class="text-xs text-slate-500 mt-2">Enabling compliance checks with advanced photometers and microbiological nutrient plates.</p>
                    </div>
                    <div class="p-6 bg-[#F8FAF6] border border-gray-100 rounded-3xl">
                        <h3 class="font-bold text-brand-dark text-sm flex items-center gap-2"><i class="ph ph-student text-brand-secondary"></i> Educational &amp; Research Centers</h3>
                        <p class="text-xs text-slate-500 mt-2">Durable laboratory layouts, borosilicate glassware, and synthesis reagents in high volumes.</p>
                    </div>
                </div>

            </div>
        </div>
    </section>

    <!-- Procurement Consultation CTA Section -->
    <section id="contact" class="py-24 bg-[#F8FAF6] relative border-t border-gray-100">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="bg-brand-primary rounded-[3rem] overflow-hidden shadow-2xl border border-white/5 relative">
                
                <div class="grid lg:grid-cols-12 items-stretch">
                    <!-- Text Area -->
                    <div class="lg:col-span-7 p-8 md:p-16 text-white space-y-6 relative z-10 flex flex-col justify-center">
                        <i class="ph-fill ph-file-text text-brand-accent text-5xl animate-pulse"></i>
                        <h2 class="text-3xl sm:text-5xl font-black leading-tight">Need Professional <br class="hidden sm:inline"/>Technical Solutions?</h2>
                        <p class="text-slate-300 leading-relaxed text-sm max-w-xl">
                            Our corporate specialists are prepared to perform professional laboratory equipment sales and custom configurations for your organization. Submit your active request details now to initiate a custom corporate bid.
                        </p>
                        
                        <div class="flex flex-col sm:flex-row gap-4 pt-4">
                            <a href="tel:+923326079992" class="bg-brand-accent hover:bg-brand-accentHover text-brand-dark px-6 py-4 rounded-full font-bold transition-all text-xs tracking-wider uppercase flex items-center justify-center gap-2">
                                <i class="ph-fill ph-phone-call"></i> Call +92 332 6079992
                            </a>
                            <a href="mailto:info@biosafenterprises.com" class="bg-white/10 hover:bg-white/20 border border-white/20 text-white px-6 py-4 rounded-full font-bold transition-all text-xs tracking-wider uppercase flex items-center justify-center gap-2 backdrop-blur-sm">
                                <i class="ph-fill ph-envelope"></i> Email Our Sourcing Desk
                            </a>
                        </div>
                    </div>

                    <!-- Direct Sourcing Quote Submission Form -->
                    <div class="lg:col-span-5 bg-white/5 border-l border-white/10 p-8 md:p-12 relative z-10 flex flex-col justify-center">
                        <h3 class="text-white text-lg font-bold mb-6">Consolidated Sourcing Quote</h3>
                        <form class="space-y-4" onsubmit="event.preventDefault(); showQuoteReceipt();">
                            <div>
                                <label class="block text-xs font-semibold text-slate-300 mb-1">Company / Organization Name</label>
                                <input required type="text" placeholder="e.g. Bio-Pharma Laboratories" class="w-full bg-white/5 border border-white/10 rounded-xl py-3 px-4 text-white placeholder-slate-500 focus:outline-none focus:border-brand-accent focus:ring-1 focus:ring-brand-accent text-xs">
                            </div>
                            <div>
                                <label class="block text-xs font-semibold text-slate-300 mb-1">Point of Contact Phone</label>
                                <input required type="tel" placeholder="e.g. +92 332 6079992" class="w-full bg-white/5 border border-white/10 rounded-xl py-3 px-4 text-white placeholder-slate-500 focus:outline-none focus:border-brand-accent focus:ring-1 focus:ring-brand-accent text-xs">
                            </div>
                            <div>
                                <label class="block text-xs font-semibold text-slate-300 mb-1">Selected Systems to Quote</label>
                                <textarea id="cart-text-area" readonly placeholder="No items selected yet. Click 'Add to Sourcing List' on featured systems above or search above." class="w-full bg-white/5 border border-white/10 rounded-xl py-3 px-4 text-slate-300 placeholder-slate-500 focus:outline-none focus:border-brand-accent focus:ring-1 focus:ring-brand-accent text-xs h-24 resize-none"></textarea>
                            </div>
                            <button type="submit" class="w-full bg-brand-accent hover:bg-brand-accentHover text-brand-dark font-extrabold py-3.5 rounded-xl transition-all text-xs tracking-wider uppercase mt-4">
                                Submit Sourcing Inquiry
                            </button>
                        </form>
                        <!-- Feedback Box -->
                        <div id="quote-success-box" class="hidden mt-4 p-4 bg-emerald-950/80 border border-emerald-500/30 rounded-xl text-center">
                            <p class="text-xs text-emerald-400 font-bold flex items-center justify-center gap-1.5">
                                <i class="ph-bold ph-seal-check text-base"></i> Inquiry Logged. Sourcing Engineers will contact you.
                            </p>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>

    <!-- Floating Sourcing Cart Drawer -->
    <div id="cart-drawer" class="fixed inset-y-0 right-0 w-80 bg-white shadow-2xl z-[100] transform translate-x-full transition-transform duration-300 border-l border-gray-200 p-6 flex flex-col justify-between hidden">
        <div>
            <div class="flex justify-between items-center pb-4 border-b border-gray-100">
                <h4 class="font-extrabold text-brand-dark flex items-center gap-2"><i class="ph-bold ph-clipboard-text"></i> Quote Manifest</h4>
                <button onclick="toggleCartDrawer()" class="p-2 hover:bg-slate-100 rounded-lg text-slate-500"><i class="ph ph-x text-lg"></i></button>
            </div>
            
            <div id="cart-items" class="py-6 space-y-4 text-xs text-slate-600">
                <p id="empty-cart-text" class="text-slate-400 text-center py-8">Your list is currently empty. Scroll to featured systems to add items.</p>
            </div>
        </div>

        <div class="space-y-3 pt-4 border-t border-gray-100">
            <a href="#contact" onclick="toggleCartDrawer()" class="w-full bg-brand-primary hover:bg-brand-secondary text-white text-xs font-bold py-3.5 rounded-xl uppercase tracking-wider text-center block">
                Transfer to Sourcing Form
            </a>
            <button onclick="clearCart()" class="w-full bg-slate-100 hover:bg-slate-200 text-slate-600 text-xs font-bold py-3 rounded-xl uppercase tracking-wider">
                Clear List
            </button>
        </div>
    </div>

    <!-- Corporate Sourcing Footer -->

<?php require BIOSAF_INCLUDES . '/footer.php';
